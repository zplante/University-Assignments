COPY Lab1.Stores FROM stdin USING DELIMITERS '|';
1|Raynor-Purdy|North|47913 Toccara Square|Ben Romaguera
2|Schroeder Bahringer and Pfannerstill|East |465 Wynell Alley|Franklyn Waelchi
3|Schultz Murazik and Balistreri|South|864 Elizabet Roads|Joan Kunde
4|Littel-Lang|East |3269 Jerome Manors|Manda Spinka
5|Yost Inc|South|33092 Robel Village|Val Considine III
6|Swift Wolf and Cole|West |5155 Mui Causeway|Mr. Wilhelmina Mosciski
7|Gibson-Halvorson|North|670 Sporer Plains|Shandi Conn
8|Bernhard and Sons|South|847 Domenic Alley|Susy Jenkins
9|Effertz-O Hara|West |70588 Tracy Glen|Kasey Hayes
10|Labadie Rohan and Ward|East |5775 Sean Rest|Anneliese Shanahan
11|Gerlach Breitenberg and Beahan|North|81369 Leonie Field|Mickey Fahey MD
12|Rogahn Inc|South|38109 Velvet Circles|Percy Altenwerth
13|Kerluke-Sporer|East |6029 Lorri Branch|Carman Beahan III
14|Ziemann Rempel and Kirlin|South|11106 Cornell Key|Deshawn Hahn Jr.
15|Schulist-Sipes|North|976 Adrianna Stravenue|Vincenzo Wolff
16|Bednar LLC|West |300 Leigh Hill|Elias Vandervort
17|Kassulke Feil and Spinka|South|6746 Albertina Parks|Roberto Pfannerstill
18|Stehr-Rohan|West |244 Schiller Track|Miss Armando Cruickshank
19|Bailey-Kuhic|North|89697 Botsford Glens|Nana Botsford DVM
20|Littel Harvey and Oberbrunner|West |8927 Stefan Falls|Siu Spinka
\.

COPY Lab1.Products FROM stdin USING DELIMITERS '|';
100|Aerodynamic Rubber Hat|Nienow Group|18.91|4
101|Ergonomic Concrete Pants|Boehm-Bauch|73.10|6
102|Rustic Wool Hat|Hermann-Olson|96.71|5
103|Mediocre Rubber Computer|Schumm-Ward|47.00|7
104|Intelligent Concrete Bench|Jones-Collier|41.21|9
105|Durable Steel Table|Marquardt Kuhlman and Bins|84.21|9
106|Mediocre Granite Hat|Schuppe-Sauer|98.60|8
107|Enormous Linen Bottle|Ruecker LLC|50.21|8
108|Synergistic Plastic Clock|Sawayn Pfeffer and Swift|123.90|9
109|Synergistic Silk Lamp|Ortiz Beahan and Hilpert|18.41|4
110|Heavy Duty Steel Lamp|Leuschke Inc|37.00|5
111|Rustic Rubber Lamp|Hessel Inc|82.10|6
112|Sleek Bronze Coat|Trantow LLC|90.91|9
113|Fantastic Granite Lamp|Trantow LLC|54.01|3
114|Practical Wool Plate|Bins Homenick and Christiansen|16.81|6
115|Awesome Steel Gloves|Ratke-Torp|87.10|8
116|Awesome Wool Plate|Jenkins LLC|69.90|3
117|Intelligent Rubber Table|Mayer-OReilly|104.51|7
118|Rustic Wooden Clock|Connelly Dicki and Sauer|58.20|8
119|Small Paper Clock|Luettgen Inc|102.61|9
120|Lightweight Paper Bottle|Wyman Group|58.70|9
121|Durable Linen Bag|Langworth-Yost|72.81|3
122|Gorgeous Cotton Pants|Smith-Ziemann|222.71|8
123|Practical Bronze Wallet|Waelchi Rolfson and Powlowski|45.20|3
124|Aerodynamic Steel Bag|Crona Mraz and Bailey|78.61|6
125|Sleek Bronze Lamp|Denesik Group|19.01|9
126|Small Paper Wallet|Lueilwitz-Bartell|89.61|9
127|Awesome Marble Gloves|Wiegand-Walsh|267.20|5
128|Rustic Iron Hat|Hane-Robel|35.01|5
129|Enormous Granite Shirt|Buckridge-Farrell|57.51|7
130|Intelligent Marble Wallet|Crooks Gutkowski and Ferry|17.11|4
131|Small Bronze Coat|Beier-Parisian|16.70|3
132|Sleek Wool Gloves|Dibbert Inc|26.81|9
133|Mediocre Aluminum Gloves|Hayes and Sons|63.71|3
134|Intelligent Granite Bottle|Kessler-Tromp|86.70|8
135|Awesome Wooden Lamp|Hamill-Pouros|81.61|5
136|Gorgeous Steel Computer|Gleason-Dare|93.50|7
137|Sleek Concrete Keyboard|Schmidt-Batz|88.40|7
138|Aerodynamic Cotton Keyboard|Kassulke-Streich|65.81|6
139|Awesome Concrete Coat|Mante LLC|37.51|4
140|Enormous Rubber Shirt|Olson-McGlynn|46.41|9
141|Gorgeous Rubber Keyboard|Kozey-Buckridge|90.20|8
142|Aerodynamic Steel Gloves|Bradtke-Rosenbaum|112.70|4
143|Intelligent Wooden Watch|Johnson Satterfield and Hudson|198.71|7
144|Lightweight Aluminum Gloves|Connelly Crooks and Schmitt|186.41|9
145|Heavy Duty Copper Bag|Bergstrom and Sons|42.90|5
146|Rustic Marble Keyboard|Schuster Abbott and Mante|87.20|4
147|Ergonomic Silk Table|Turner Mann and Rosenbaum|75.00|4
148|Gorgeous Iron Bench|Torp and Sons|13.00|7
149|Awesome Aluminum Knife|Paucek LLC|66.41|8
150|Awesome Plastic Keyboard|Satterfield Paucek and Breitenberg|80.51|4
151|Small Aluminum Table|DuBuque Robel and Luettgen|57.81|7
152|Gorgeous Granite Car|Koelpin Daugherty and Gutmann|66.61|9
153|Mediocre Leather Knife|Ferry Crona and Friesen|78.50|7
154|Synergistic Steel Coat|Mohr Trantow and Ortiz|67.61|6
155|Heavy Duty Leather Gloves|Johnston Schuppe and Lowe|47.91|9
156|Small Wooden Lamp|Roob-Satterfield|98.11|4
157|Awesome Steel Chair|Littel Mayert and Ruecker|44.60|4
158|Ergonomic Cotton Keyboard|Adams Group|37.80|6
159|Intelligent Silk Bag|Dibbert and Sons|87.21|4
160|Intelligent Aluminum Keyboard|Mitchell Stoltenberg and Marvin|158.90|7
161|Gorgeous Wooden Bag|Lynch McGlynn and Hessel|65.40|7
162|Mediocre Copper Wallet|Jerde-Weber|89.70|6
163|Durable Paper Table|Satterfield Botsford and Rempel|72.11|3
164|Gorgeous Wooden Shoes|Pacocha LLC|46.00|3
165|Intelligent Wool Bag|Flatley-Powlowski|99.51|3
166|Fantastic Marble Hat|Rodriguez-Huels|41.51|4
167|Gorgeous Wool Hat|Pollich LLC|35.31|7
168|Sleek Plastic Shirt|Schoen Heller and Renner|83.41|7
169|Fantastic Wooden Knife|Abshire-Jakubowski|17.81|6
170|Sleek Silk Bench|Altenwerth Wintheiser and Brekke|28.01|6
171|Incredible Silk Wallet|Gerlach-Considine|46.50|8
172|Intelligent Marble Shirt|Fritsch-Runte|48.30|4
173|Gorgeous Paper Plate|Schoen-Corkery|60.90|4
174|Small Wool Coat|Kunze Schumm and Abbott|54.91|9
175|Awesome Leather Bottle|Wisozk Gutkowski and Schuppe|84.21|9
176|Heavy Duty Steel Keyboard|Bernhard-Moore|64.91|3
177|Aerodynamic Concrete Chair|Zemlak Kohler and Lemke|39.70|9
178|Sleek Iron Coat|King LLC|147.41|3
179|Aerodynamic Linen Car|Tillman Adams and Kunze|81.21|9
180|Aerodynamic Bronze Table|Quigley Inc|27.00|3
181|Incredible Iron Bench|Mills Huel and Hirthe|90.40|7
182|Heavy Duty Paper Clock|Bode-Hackett|36.21|9
183|Sleek Linen Bottle|Ward Sauer and Haley|27.91|6
184|Practical Wool Table|Bashirian Wiza and Parisian|93.50|9
185|Incredible Leather Chair|McLaughlin-Herman|60.91|3
186|Lightweight Iron Bottle|Breitenberg Kunde and Rutherford|95.60|4
187|Synergistic Silk Hat|Buckridge LLC|79.91|5
188|Sleek Bronze Gloves|Stracke LLC|55.41|4
189|Durable Wooden Plate|Ziemann-Sawayn|63.30|7
190|Heavy Duty Bronze Wallet|Lehner Koss and Stiedemann|32.41|5
191|Lightweight Marble Car|Crist and Sons|34.30|6
192|Intelligent Bronze Car|Rolfson-Smith|16.50|8
193|Small Iron Clock|Waters Kemmer and White|55.91|8
194|Mediocre Linen Shoes|Hodkiewicz Collier and Wehner|36.21|6
195|Mediocre Bronze Clock|Schuster-Frami|84.00|7
196|Small Concrete Bench|Jacobson Inc|41.30|9
197|Small Steel Plate|Mertz Morar and Kris|65.21|3
198|Aerodynamic Aluminum Bag|Rohan-Feeney|38.41|4
199|Heavy Duty Concrete Wallet|Hand LLC|76.30|9
\.

COPY Lab1.Customers FROM stdin USING DELIMITERS '|';
1008|Jerrod White|6122 Fausto Flat|2017-03-31|70.99|2018-03-14|H
1009|Xavier Wyman V|951 Langworth Well|2017-11-19|108.95|2018-03-14|H
1012|Miss Garland Friesen|30927 Bashirian Corners|2017-03-18|1736.79|2018-03-11|M
1020|Cassi Kovacek|91296 Jeanine Hill|2017-02-02|1113.01|2018-03-12|L
1002|India Crona|15480 Moore Valley|2017-10-30|0.00|2018-03-10|H
1003|Ms. Dung Quitzon|9133 Herman Mountain|2017-04-17|0.00|2018-03-17|H
1006|Mr. Tressa Hayes|4917 Blake Skyway|2017-03-24|0.00|2018-03-10|H
1007|Orville Krajcik|3239 Tremblay Square|2017-09-09|0.00|2018-03-29|H
1010|Darnell Hagenes|123 Smitham Crescent|2017-05-29|0.00|2018-03-26|H
1011|Corrinne Pouros DVM|462 Halvorson Knolls|2017-05-11|314.14|2018-03-13|M
1013|Mrs. Morgan Bernhard|959 Miller Crescent|2017-06-24|324.66|2018-03-26|M
1014|Elfrieda Kuhn|78872 Joesph Mountain|2017-10-14|141.50|2018-03-03|M
1015|Karl Lynch MD|9985 Chelsey Field|2017-06-26|58.66|2018-03-03|M
1016|Eustolia Wisoky|3497 Brad Alley|2017-12-08|243.78|2018-03-19|L
1017|Stephen Bergstrom|2663 Florencia Square|2017-11-16|656.02|2018-03-06|L
1018|Laurice Hilll|53518 Pouros Stravenue|2017-04-26|217.38|2018-03-03|L
1019|Pasquale Herman|741 Huels Cape|2017-09-10|0.00|2018-03-22|L
1001|Ami Maggio|650 Kessler Common|2017-09-07|319.04|2018-03-11|H
1004|Mee Spencer|10693 Marsha Fall|2017-03-01|51.44|2018-03-08|H
1005|Kirk Batz|46945 Cole Landing|2017-06-09|79.00|2018-03-17|H
\.

COPY Lab1.Sales FROM stdin USING DELIMITERS '|';
118|1001|17|2018-01-16|46.56|9
170|1002|17|2018-01-16|16.81|7
145|1003|17|2018-01-17|21.45|2
198|1004|18|2018-01-17|15.36|4
139|1005|1|2018-01-18|15.00|6
106|1006|13|2018-01-18|78.88|5
105|1007|5|2018-01-19|75.79|6
144|1008|16|2018-01-19|167.76|8
165|1009|16|2018-01-16|29.85|7
125|1010|14|2018-01-16|17.11|3
106|1011|12|2018-01-17|98.60|7
160|1012|7|2018-01-17|158.90|11
147|1013|15|2018-01-18|75.00|7
172|1014|6|2018-01-18|48.30|5
190|1015|1|2018-01-19|32.41|9
151|1016|4|2018-01-19|57.81|6
105|1017|6|2018-01-16|84.21|10
174|1018|7|2018-01-16|54.91|6
111|1019|5|2018-01-17|82.10|4
142|1020|14|2018-01-17|112.70|10
222|2222|22|2018-01-18|231.56|2
223|3333|33|2018-01-19|24.60|2
\.

COPY Lab1.Payments FROM stdin USING DELIMITERS '|';
1001|Ami Maggio|2018-02-17|100.00|f
1003|Ms. Dung Quitzon|2018-02-01|42.90|t
1004|Mee Spencer|2018-02-17|10.00|f
1005|Kirk Batz|2018-02-25|11.00|f
1006|Mr. Tressa Hayes|2018-02-19|394.40|t
1007|Orville Krajcik|2018-02-12|454.74|t
1008|Jerrod White|2018-02-06|1271.09|f
1009|Xavier Wyman V|2018-02-06|100.00|f
1011|Corrinne Pouros DVM|2018-02-19|376.06|f
1013|Mrs. Morgan Bernhard|2018-02-26|200.34|f
1014|Elfrieda Kuhn|2018-02-04|100.00|f
1015|Karl Lynch MD|2018-02-21|233.03|f
1016|Eustolia Wisoky|2018-02-19|103.08|f
1017|Stephen Bergstrom|2018-02-21|186.08|f
1018|Laurice Hilll|2018-02-23|112.08|f
1019|Pasquale Herman|2018-02-24|328.40|t
1002|India Crona|2018-02-19|117.67|t
1010|Darnell Hagenes|2018-02-03|51.33|t
1012|Miss Garland Friesen|2018-02-28|11.11|f
1020|Cassi Kovacek|2018-02-16|13.99|f
\.

COPY Lab1.Day FROM stdin USING DELIMITERS '|';
1/15/18|C
1/16/18|N
1/17/18|N
1/18/18|N
1/19/18|N
1/20/18|C
1/21/18|C
1/22/18|N
1/23/18|N
1/24/18|N
1/25/18|N
1/26/18|N
\.
