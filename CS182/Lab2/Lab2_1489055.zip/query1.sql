SELECT productID, productName
FROM Products
WHERE productName LIKE 'Intelligent%'
ORDER BY productName;